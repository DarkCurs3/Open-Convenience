﻿using ReactiveUI;

namespace ERClipGeneratorTool.ViewModels
{
    public class ViewModelBase : ReactiveObject { }
}